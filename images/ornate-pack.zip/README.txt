
Ornate Pack — drop-in assets for a gold, old-world jewelry theme
================================================================

Files:
- /styles/ornate.css — gold gradients, framed tiles, buttons, dividers
- /assets/ornaments/*.svg — flourishes, corners, medallion, button endcaps
- /index-demo.html — a minimal usage example

How to integrate with your GitHub Pages repo:
1) Copy the 'styles' folder and 'assets/ornaments' folder into your repo.
2) Link the CSS: <link rel="stylesheet" href="/styles/ornate.css">
   (Make sure the path matches your repo structure.)
3) Add the top flourish and a framed hero section:
   <div class="ornament-top"></div>
   <section class="hero gilded-border frame">…</section>
4) For product tiles, use:
   <article class="tile gilded-border frame">…</article>
5) Use <div class="divider"></div> anywhere you want a gold divider bar.
6) Buttons: <a class="btn-gold">Label</a>

Notes:
- The corners use ::before to place SVG corner caps and ::after for a subtle inner outline.
- You can tune the card width with CSS grid minmax; see the .catalog rule.
- Colors are driven by CSS variables at the top of ornate.css.

Optional tweaks:
- Increase the flourish size: .ornament-top{ --h:110px; }
- Tighten the inner outline: .frame::after{ outline-offset:-6px; }
